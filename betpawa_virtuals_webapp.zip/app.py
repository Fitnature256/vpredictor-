from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)

DB_NAME = 'virtuals.db'

def init_db():
    if not os.path.exists(DB_NAME):
        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS matches (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            home_team TEXT,
                            away_team TEXT,
                            home_goals INTEGER,
                            away_goals INTEGER,
                            match_time TEXT
                        )''')
            conn.commit()

def generate_prediction():
    with sqlite3.connect(DB_NAME) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM matches ORDER BY id DESC LIMIT 10")
        recent_matches = c.fetchall()

    if not recent_matches:
        return "Not enough data for prediction."

    over_2_5 = sum(1 for m in recent_matches if m[3] + m[4] > 2)
    under_2_5 = 10 - over_2_5

    if over_2_5 >= 7:
        return "Next game likely UNDER 2.5 goals (based on last 10 games)"
    elif under_2_5 >= 7:
        return "Next game likely OVER 2.5 goals (based on last 10 games)"
    else:
        return "No strong pattern detected."

@app.route('/')
def index():
    prediction = generate_prediction()
    with sqlite3.connect(DB_NAME) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM matches ORDER BY id DESC LIMIT 10")
        match_history = c.fetchall()
    return render_template('index.html', prediction=prediction, match_history=match_history)

@app.route('/input', methods=['GET', 'POST'])
def input_match():
    if request.method == 'POST':
        home_team = request.form['home_team']
        away_team = request.form['away_team']
        home_goals = int(request.form['home_goals'])
        away_goals = int(request.form['away_goals'])
        match_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with sqlite3.connect(DB_NAME) as conn:
            c = conn.cursor()
            c.execute("INSERT INTO matches (home_team, away_team, home_goals, away_goals, match_time) VALUES (?, ?, ?, ?, ?)",
                      (home_team, away_team, home_goals, away_goals, match_time))
            conn.commit()

        return redirect(url_for('index'))
    return render_template('input.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
